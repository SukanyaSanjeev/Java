package demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BouquetStorage {
    private Map<String, String> bouquetMap;

    public BouquetStorage() {
        this.bouquetMap = new HashMap<>();
    }

    public void addBouquet(String bouquetName, List<String> flowers) {
        for (String flower : flowers) {
            bouquetMap.put(flower.toLowerCase(), bouquetName);
        }
    }

    public String findBouquet(String... flowers) {
        for (String flower : flowers) {
            String bouquet = bouquetMap.get(flower.toLowerCase());
            if (bouquet != null) {
                return bouquet;
            }
        
        }
        return "None";
    }

    public static void main(String[] args) {
        BouquetStorage storage = new BouquetStorage();
        
        
//        storage.addBouquet("Bouquet 1", "Red", "Rose", "White", "Yellow");
//        storage.addBouquet("Bouquet 1", "Tulip", "White", "Purple", "Rose", "Pink", "White", "Lily", "Orange");
//        storage.addBouquet("Bouquet 2", "Chrysanthemum", "Yellow", "Balsam", "Pink");

        List<String> Rose=new ArrayList<>();
		Rose.add("Red");
		Rose.add("White");
		Rose.add("Yellow");
		
		List<String> Tulip=new ArrayList<>();
		Tulip.add("white");
		Tulip.add("purple");
		
		
		List<String> Lily=new ArrayList<>();
		Lily.add("white");
        
        storage.addBouquet("Bouquet1", Rose);
        storage.addBouquet("Bouquet1", Tulip);
        storage.addBouquet("Bouquet1", Lily);
        
        List<String> Rose1=new ArrayList<>();
		Rose1.add("pink");
		Rose1.add("orange");
		
		
		List<String> chrysanthemum=new ArrayList<>();
		chrysanthemum.add("yellow");
		
		
		
		List<String> Balsam=new ArrayList<>();
		Balsam.add("white");
       
		storage.addBouquet("Bouquet2", chrysanthemum);
        storage.addBouquet("Bouquet2", Balsam);
       
        System.out.println("Input: Red Rose | Output: " + storage.findBouquet("Red", "Rose"));
        System.out.println("Input: Pink Lily | Output: " + storage.findBouquet("pink", "lily"));
    }
}

