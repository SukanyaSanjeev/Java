package demo;

public class ClubRank {
    public static int toFindHarperRank(int[] ranks, int harperRank) {
        for (int i = 0; i < ranks.length; i++) {
            if (ranks[i] > harperRank) {
                return i + 1;
            }
        }
        return ranks.length + 1; 
    }

    public static void main(String[] args) {
        int[] other_ranks = {7, 28, 67, 20, 5, 44}; 
        int harperRank = 45;

        int harperRankPosition = toFindHarperRank(other_ranks, harperRank);
        if (harperRankPosition <= other_ranks.length) {
            System.out.println("Rank of Harper: " + harperRankPosition);
        } else {
            System.out.println("Harper's rank is higher ");
        }
    }
}
