package demo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LogAnalyzer {

    public static void main(String[] args) {
        String logFilePath = "trace.log";
        String jobName = "J1";
        String timestampString = "2023-06-29 04:04:04";

        try {
            Date targetTimestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(timestampString);
            String firstLogAfterTimestamp = findFirstLogAfterTimestamp(logFilePath, jobName, targetTimestamp);
            System.out.println("First log of " + jobName + " after " + timestampString + ": " + firstLogAfterTimestamp);
        } catch (ParseException e) {
            System.out.println("Error parsing timestamp: " + e.getMessage());
        }
    }

    public static String findFirstLogAfterTimestamp(String logFilePath, String jobName, Date timestamp) {
        String firstLog = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(logFilePath))) {
            String line;
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date logTimestamp;
            while ((line = reader.readLine()) != null) {
                if (line.contains(jobName)) {
                    int timestampStartIndex = line.indexOf("2023");
                    if (timestampStartIndex != -1) {
                        String timestampString = line.substring(timestampStartIndex, timestampStartIndex + 19);
                        logTimestamp = dateFormat.parse(timestampString);
                        if (logTimestamp.after(timestamp)) {
                            firstLog = line;
                            break;
                        }
                    }
                }
            }
        } catch (IOException | ParseException e) {
            System.out.println("Error reading log file: " + e.getMessage());
        }

        return firstLog;
    }
}
