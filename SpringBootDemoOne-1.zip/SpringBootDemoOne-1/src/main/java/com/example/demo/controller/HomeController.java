package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entity.Student;

@Controller
public class HomeController {

	@RequestMapping(value = "/")
	public String getIndexPage() {
		System.out.println("Check Index Page");
		return "index";
	}
	
	@RequestMapping(value = "/register")
    public String getRegsiterPage() {
		System.out.println("Calling Register Page.");
		return "register";
	}
	
	@RequestMapping(value = "/reg")
	public String getRegisterData(@ModelAttribute Student student) {
		System.out.println("Check Student Data :  " + student);
		return "index";
	}
 
}
