package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootDemoOne1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemoOne1Application.class, args);
	}

}
